const TEST_DEFS=[
 {id:"screen",name:"Display test",desc:"Visual color/brightness test",icon:"▦"},
 {id:"touch",name:"Touch test",desc:"Detect touch interaction",icon:"⌁"},
 {id:"camera",name:"Camera access",desc:"Request camera permission",icon:"◉"},
 {id:"microphone",name:"Microphone access",desc:"Request microphone permission",icon:"◌"},
 {id:"speaker",name:"Speaker test",desc:"Play browser test tone",icon:"◒"},
 {id:"vibration",name:"Vibration",desc:"Send a vibration command",icon:"≋"},
 {id:"battery",name:"Battery API",desc:"Read browser-exposed battery level",icon:"▰"},
 {id:"network",name:"Network",desc:"Check online status and connection hint",icon:"⌁"}
];
const results={};
function buildDiagList(){
 const el=document.getElementById("diagList");
 el.innerHTML=TEST_DEFS.map(t=>`<div class="diag-row"><div class="left"><span class="ico">${t.icon}</span><div><b>${t.name}</b><div class="muted">${t.desc}</div></div></div><div><span id="diag-${t.id}" class="status">Ready</span> <button class="ghost" onclick="runTest('${t.id}')">Run</button></div></div>`).join("");
}
function setResult(id,state,value){
 results[id]={state,value};
 const s=document.getElementById("diag-"+id); if(s){s.textContent=value;s.className="status "+state}
 const q=document.getElementById("status-"+id); if(q){q.textContent=value;q.className=state}
 updateScore();
}
async function runTest(id){
 if(id==="screen"){const old=document.body.style.background; document.body.style.background="#fff"; toast("Look at the screen: visual test active"); setTimeout(()=>{document.body.style.background=old||"#07101d";setResult(id,"pass","Completed");},1300);return}
 if(id==="touch"){setResult(id,"warn","Touch screen to confirm"); const h=()=>{setResult(id,"pass","Detected");window.removeEventListener("touchstart",h)};window.addEventListener("touchstart",h);return}
 if(id==="camera"){try{const s=await navigator.mediaDevices.getUserMedia({video:true});s.getTracks().forEach(t=>t.stop());setResult(id,"pass","Access granted")}catch(e){setResult(id,"fail","Denied / unavailable")}return}
 if(id==="microphone"){try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop());setResult(id,"pass","Access granted")}catch(e){setResult(id,"fail","Denied / unavailable")}return}
 if(id==="speaker"){try{const ctx=new (window.AudioContext||window.webkitAudioContext)();const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=700;o.connect(g);g.connect(ctx.destination);g.gain.value=.06;o.start();setTimeout(()=>{o.stop();ctx.close()},450);setResult(id,"pass","Tone played")}catch(e){setResult(id,"fail","Audio unavailable")}return}
 if(id==="vibration"){if(navigator.vibrate){navigator.vibrate([200,100,200]);setResult(id,"pass","Command sent")}else setResult(id,"warn","Not supported");return}
 if(id==="battery"){const b=await getBatteryInfo(); if(b){setResult(id,"pass",`${b.level}%${b.charging?" • charging":""}`);document.getElementById("batteryShort").textContent=b.level+"%"}else setResult(id,"warn","Not exposed");return}
 if(id==="network"){const d=getDeviceData();setResult(id,d.online==="Online"?"pass":"fail",d.online+(d.connection!=="Not exposed"?" • "+d.connection:""));return}
}
async function runAllTests(){for(const t of TEST_DEFS){await runTest(t.id);await new Promise(r=>setTimeout(r,180))}}
function updateScore(){
 const ids=TEST_DEFS.map(t=>t.id), done=ids.filter(id=>results[id]?.state).length, passed=ids.filter(id=>results[id]?.state==="pass").length;
 document.getElementById("completed").textContent=`${done}/${ids.length}`;
 if(!done){document.getElementById("score").textContent="—";return}
 const score=Math.round((passed/ids.length)*100);
 document.getElementById("score").textContent=score;
 document.getElementById("scoreText").textContent=score>=80?"Good coverage":score>=50?"Some checks need attention":"Several checks need attention";
 document.getElementById("reportScore").textContent=score;
 document.getElementById("reportBadge").textContent=`${done}/${ids.length} TESTS RUN`;
 renderReport();
}
function renderReport(){
 const el=document.getElementById("reportList");
 el.innerHTML=TEST_DEFS.filter(t=>results[t.id]).map(t=>`<div class="report-row"><span>${t.name}</span><b class="${results[t.id].state}">${results[t.id].value}</b></div>`).join("");
 document.getElementById("reportDevice").textContent=`${getDeviceData().os} diagnostic report`;
 document.getElementById("reportDate").textContent=new Date().toLocaleString();
}
window.runTest=runTest;window.runAllTests=runAllTests;