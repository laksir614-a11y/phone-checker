const I18N={
 en:{dashboard:"Dashboard",diagnostics:"Diagnostics",deviceInfo:"Device Info",report:"Report",premium:"Premium",settings:"Settings",advancedDiagnostics:"Advanced diagnostics"},
 fr:{dashboard:"Tableau",diagnostics:"Diagnostics",deviceInfo:"Infos appareil",report:"Rapport",premium:"Premium",settings:"Réglages",advancedDiagnostics:"Diagnostics avancés"},
 de:{dashboard:"Übersicht",diagnostics:"Diagnose",deviceInfo:"Geräteinfo",report:"Bericht",premium:"Premium",settings:"Einstellungen",advancedDiagnostics:"Erweiterte Diagnose"},
 ar:{dashboard:"لوحة التحكم",diagnostics:"الفحص",deviceInfo:"معلومات الجهاز",report:"التقرير",premium:"Premium",settings:"الإعدادات",advancedDiagnostics:"فحص متقدم"}
};
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function go(page){
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active-page"));
 document.getElementById(page).classList.add("active-page");
 document.querySelectorAll(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.page===page));
 const title=document.querySelector(`[data-page="${page}"] span`)?.textContent || page;
 document.getElementById("pageTitle").textContent=title;
 document.querySelector(".sidebar")?.classList.remove("open");
 if(page==="report")renderReport();
}
function setTheme(){document.body.classList.toggle("light");localStorage.setItem("pc-theme",document.body.classList.contains("light")?"light":"dark")}
function language(lang){
 document.querySelectorAll("[data-i18n]").forEach(el=>{const k=el.dataset.i18n; if(I18N[lang]?.[k])el.textContent=I18N[lang][k]});
 document.documentElement.dir=lang==="ar"?"rtl":"ltr";
 document.getElementById("language").value=lang;document.getElementById("language2").value=lang;
 localStorage.setItem("pc-lang",lang);
}
function validImei(s){
 if(!/^\d{15}$/.test(s))return false;
 let sum=0;for(let i=0;i<15;i++){let n=+s[i];if(i%2===1){n*=2;if(n>9)n-=9}sum+=n}return sum%10===0;
}
document.addEventListener("DOMContentLoaded",async()=>{
 buildDiagList();renderDeviceInfo();language(localStorage.getItem("pc-lang")||"en");
 if(localStorage.getItem("pc-theme")==="light")document.body.classList.add("light");
 document.querySelectorAll(".nav-item").forEach(n=>n.addEventListener("click",()=>go(n.dataset.page)));
 document.querySelectorAll("[data-page-link]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.pageLink)));
 document.querySelectorAll(".check-card").forEach(b=>b.addEventListener("click",()=>{go("diagnostics");runTest(b.dataset.test)}));
 document.getElementById("startCheck").onclick=()=>{go("diagnostics");runAllTests()};
 document.getElementById("runAll").onclick=runAllTests;
 document.getElementById("print").onclick=()=>window.print();
 document.getElementById("reset").onclick=()=>{Object.keys(results).forEach(k=>delete results[k]);buildDiagList();updateScore();document.getElementById("reportList").innerHTML="";toast("Report reset")};
 document.getElementById("themeBtn").onclick=setTheme;document.getElementById("themeBtn2").onclick=setTheme;
 document.getElementById("mobileMenu").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");
 document.getElementById("language").onchange=e=>language(e.target.value);document.getElementById("language2").onchange=e=>language(e.target.value);
 document.getElementById("checkImei").onclick=()=>{const v=document.getElementById("imei").value.trim();const box=document.getElementById("imeiResult");if(validImei(v)){box.innerHTML='<span class="status pass">✓ IMEI checksum is valid.</span>'}else{box.innerHTML='<span class="status fail">✕ Invalid format or checksum.</span>'}};
 const b=await getBatteryInfo();if(b)document.getElementById("batteryShort").textContent=b.level+"%";
});
