function getDeviceData(){
 const ua=navigator.userAgent;
 let os="Unknown";
 if(/Android/i.test(ua)) os="Android";
 else if(/iPhone|iPad|iPod/i.test(ua)) os="iOS";
 else if(/Windows/i.test(ua)) os="Windows";
 else if(/Mac OS/i.test(ua)) os="macOS";
 else if(/Linux/i.test(ua)) os="Linux";
 let browser="Unknown";
 if(/Edg/i.test(ua)) browser="Edge";
 else if(/Chrome/i.test(ua)) browser="Chrome";
 else if(/Firefox/i.test(ua)) browser="Firefox";
 else if(/Safari/i.test(ua)) browser="Safari";
 const d={os,browser,ua,screen:`${screen.width} × ${screen.height}`,pixelRatio:window.devicePixelRatio||1,
 language:navigator.language||"Unknown",online:navigator.onLine?"Online":"Offline",
 cores:navigator.hardwareConcurrency||"Not exposed",memory:navigator.deviceMemory?`${navigator.deviceMemory} GB (approx.)`:"Not exposed",
 touch:"ontouchstart" in window || navigator.maxTouchPoints>0 ? "Supported":"Not detected",
 connection:navigator.connection?.effectiveType||"Not exposed"};
 return d;
}
function renderDeviceInfo(){
 const d=getDeviceData();
 const items=[["Operating system",d.os],["Browser",d.browser],["Screen",d.screen],["Pixel ratio",d.pixelRatio],["Language",d.language],["Network",d.online],["CPU threads",d.cores],["Memory hint",d.memory],["Touch",d.touch],["Connection",d.connection],["User agent",d.ua]];
 document.getElementById("deviceInfo").innerHTML=items.map(x=>`<div class="info-item"><span>${x[0]}</span><b>${escapeHtml(String(x[1]))}</b></div>`).join("");
 document.getElementById("deviceShort").textContent=d.os;
 document.getElementById("platformShort").textContent=d.browser;
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
async function getBatteryInfo(){
 if(!navigator.getBattery) return null;
 try{
  const b=await navigator.getBattery();
  return {level:Math.round(b.level*100),charging:b.charging};
 }catch{return null}
}