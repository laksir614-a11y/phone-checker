PHONE CHECKER PRO — Web build

Open index.html in a modern browser.

This build intentionally does NOT fake restricted information:
- Browser cannot reliably expose a phone's real IMEI.
- Browser cannot verify iCloud/Activation Lock.
- Browser cannot certify battery health/cycles on iPhone.
- CPU/RAM values are browser hints, not authoritative hardware diagnostics.

Next production step:
1. Wrap the UI as Android/iOS app.
2. Add native Android diagnostics.
3. Add iOS-compatible checks.
4. Add secure backend for IMEI/device databases.
5. Add authentication, subscriptions and cloud reports.
